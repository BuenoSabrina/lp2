# Story-Manager
Personagem:
Nome
Sexo
Descrição

Local:
Nome
Descrição

Cena:
Personagem
Local
Descrição

Capítulo:
Nome
Cena

Projeto:
Nome
Capítulo

Ideia:
Nome
Descrição

Pedro Henrique Neves de Deus Barbosa
caio lopes de carvalho
